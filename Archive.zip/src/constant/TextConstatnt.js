export const wishingPage = "Hello there , How can i help you today?            What is the purpose of your visit?";
export const preferedText =   "Which employee would you prefer to schedule a meeting with?";
export const visitPurpose = "What is the purpose of your visit?";
export const AcceptedConfirmation = "The employee is ready to visit please be seated 🙂";
export const RejectedConfirmation = "sorry the person is not avalable at the moment we have convey your name and purpose of the visite to him we will reach out to you at the earliest when the employee is avilable";
export const AcceptedConfirmationSpeak = "The employee is ready to visit please be seated ";
export const RejectedConfirmationSpeak = "The employee is ready to visit please be seated ";
